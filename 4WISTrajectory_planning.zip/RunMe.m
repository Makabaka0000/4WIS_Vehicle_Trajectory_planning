    close all; clc; clear global params_; clear all;
global params_ 
for ii = 3:3
%     ii=1;
    params_.user.case_id = ii;
%     InitializeParams();
    MyInitPar();

%     tic;
    [x,y,~]=SearchAStarPath([params_.task.x0,params_.task.y0,params_.task.theta0],[params_.task.xf,params_.task.yf,params_.task.thetaf]);
    localbox_size=zeros(length(x),6);
    s=0;
    for j=1:size(x,2)
        lb=getlength(x(j),y(j));
        localbox_size(j,:)=[x(j),y(j),x(j)-lb(2),x(j)+lb(4),y(j)-lb(3),y(j)+lb(1)];
        s=s+(lb(4)+lb(2))*(lb(1)+lb(3));
    end
%     ratio=[ratio;s/(j*4*params_.hybrid_astar.FindSpacemaxs*params_.hybrid_astar.FindSpacemaxs)];
    ratio=s/(j*4*params_.hybrid_astar.FindSpacemaxs*params_.hybrid_astar.FindSpacemaxs);
    if(ratio >0.4)
        SearchTrajectoryViaFTHA();
    else

%     [x_test,y_test,theta_test]=SearchAStarPath([params_.task.x0,params_.task.y0,params_.task.theta0],[params_.task.xf,params_.task.yf,params_.task.thetaf]);
%     DrawParkingScenario();
%     DrawTrajFootprints(params_.task.xf,params_.task.yf,params_.task.thetaf);
%     plot(x_test,y_test,'LineWidth',2);
    [IsGearShift,gsp_point]=GetMapInformation();
%     SearchTrajectoryViaFTHA();
    SearchTrajectory4WIS(IsGearShift,gsp_point);
%     load('Params.mat')
    OptimizeTrajectory4WIS();
%     OptimizeTrajectoryViaLIOM();
%     if(params_.limo.is_successful)
%         x=params_.limo.x;
%         y=params_.limo.y;
%         theta=params_.limo.theta;
%         v=params_.limo.v;
%         a=params_.limo.a;
%         phy=params_.limo.phy;
%         w=params_.limo.w;
%         terminal_time=params_.limo.terminal_time;
%         save(strcat('E:\MATLAB 2019a\bin\mycor\dilemma\hybrid\res',num2str(ii)),'x','y','theta','v','a','phy','w','terminal_time','computation_time');
%     end
    end
end 
DrawParkingScenario();
plot(params_.ha_result.x,params_.ha_result.y,'LineWidth',2);
DrawTrajFootprints(params_.ha_result.x,params_.ha_result.y,params_.ha_result.theta);
% hold on
% spin=params_.ha_result.spin;
% for i=1:size(spin,1)
%     t=linspace(spin(i,3),spin(i,4),50);
%     r=params_.vehicle.length/2;
%     center=[spin(i,1),spin(i,2)];
%     x=cos(t).*r+center(1,1);
%     y=sin(t).*r+center(1,2);
%     plot(x,y,'LineWidth',2);
%     Arrow([spin(i,1),spin(i,2)],[spin(i,1)+cos(spin(i,3)),spin(i,2)+sin(spin(i,3))],'Length',1.6,'BaseAngle',9,'TipAngle',1.6,'Width',0.2);
%     Arrow([spin(i,1),spin(i,2)],[spin(i,1)+cos(spin(i,4)),spin(i,2)+sin(spin(i,4))],'Length',1.6,'BaseAngle',9,'TipAngle',1.6,'Width',0.2);
%     hold on
% end


function lb=getlength(xc,yc)
    global params_
    lb=zeros(1,4);
    is_completed=zeros(1,4);
    while(sum(is_completed)<4)
        for ind=1:4
            if(is_completed(ind))
                continue;
            end
            test=lb;
            if(test(ind)+params_.hybrid_astar.FindSpaceder_s>params_.hybrid_astar.FindSpacemaxs)
                is_completed(ind)=1;
                continue;
            end
            der_s=params_.hybrid_astar.FindSpaceder_s;
            if(isValid(xc,yc,test,ind,der_s))
                test(ind)=test(ind)+der_s;
                lb=test;
            else
                is_completed(ind)=1;
            end
        end
    end
end
function flag=isValid(x,y,trail,ind,der_s)
    global params_
    flag=0;
    x_minb=x-trail(2);y_maxb=y+trail(1);
    x_maxb=x+trail(4);y_minb=y-trail(3);
    switch ind
    case 1
        xmax=x_maxb;xmin=x_minb;ymin=y_maxb;ymax=y_maxb+der_s;
    case 2
        xmax=x_minb;xmin=x_minb-der_s;ymin=y_minb;ymax=y_maxb;
    case 3
        xmax=x_maxb;xmin=x_minb;ymin=y_minb-der_s;ymax=y_minb;
    case 4
        xmax=x_maxb+der_s;xmin=x_maxb;ymin=y_minb;ymax=y_maxb;
    otherwise
        return;
    end    
%     if((xmax>params_.scenario.xmax)||(xmin<params_.scenario.xmin)||(ymax>params_.scenario.ymax)||(ymin<params_.scenario.ymin))
%         return;
%     end
    if((xmax>params_.scenario.xmax-params_.vehicle.dual_disk_radius)||...
        (xmin<params_.scenario.xmin+params_.vehicle.dual_disk_radius)||...
        (ymax>params_.scenario.ymax-params_.vehicle.dual_disk_radius)||...
        (ymin<params_.scenario.ymin+params_.vehicle.dual_disk_radius))
        return;
    end
    
    
    
    point_nums=1000;
    vx = [linspace(xmin, xmax, point_nums), linspace(xmax, xmax, point_nums), linspace(xmax, xmin, point_nums), linspace(xmin, xmin, point_nums)];
    vy = [linspace(ymax, ymax, point_nums), linspace(ymax, ymin, point_nums), linspace(ymin, ymin, point_nums), linspace(ymin, ymax, point_nums)];
    
    
    
%     for ii = 1 : params_.obstacle.num_obs
%          if (any(inpolygon(vx, vy, params_.obs.old_dilated_obs{ii}.x,params_.obs.old_dilated_obs{ii}.y)))
%             return;
%          end
%     end
%     flag=1;
    ind_x=floor((vx-params_.scenario.xmin)/params_.hybrid_astar.resolution_dx)+1;
    ind_y=floor((vy-params_.scenario.ymin)/params_.hybrid_astar.resolution_dy)+1;
    if(any(params_.scenario.dilated_map(sub2ind(size(params_.scenario.dilated_map),ind_x,ind_y))))
        return;
    end
    flag=1;
end